package com.yourcompany.mamplus.firestore

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

data class UserPolicy(
    val isAdmin: Boolean = false,
    val blockUnknownSources: Boolean = true,
    val rootCheckEnabled: Boolean = true,
    val trustScoreCheckEnabled: Boolean = true,
    val networkCheckEnabled: Boolean = true,
    val trustedIpRange: String = "10.0.2.15/32",
    val locationRestrictionEnabled: Boolean = true,
    val whitelistCheckEnabled: Boolean = true,
    val userBehaviorCheckEnabled: Boolean = true,
    val lastLoginTimestamp: Long = 0,
    val lastKnownDeviceModel: String = "",
    val lastLoginHour: Int = 0
)

object PolicyManager {
    private val db = FirebaseFirestore.getInstance()

    suspend fun getPolicyForUser(email: String): UserPolicy {
        return try {
            val doc = db.collection("users").document(email).get().await()
            if (doc.exists()) {
                doc.toObject(UserPolicy::class.java) ?: UserPolicy()
            } else {
                UserPolicy()
            }
        } catch (e: Exception) {
            Log.e("PolicyManager", "Error fetching policy: ${e.message}")
            UserPolicy()
        }
    }

    fun updateLoginBehavior(email: String, timestamp: Long, model: String, hour: Int) {
        val updates = mapOf(
            "lastLoginTimestamp" to timestamp,
            "lastKnownDeviceModel" to model,
            "lastLoginHour" to hour
        )
        db.collection("users").document(email).update(updates)
            .addOnSuccessListener {
                Log.d("PolicyManager", "Login behavior updated for $email")
            }
            .addOnFailureListener { e ->
                Log.e("PolicyManager", "Failed to update login behavior: ${e.message}")
            }
    }
}
