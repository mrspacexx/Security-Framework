package com.yourcompany.mamplus

import android.app.KeyguardManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.google.firebase.FirebaseApp
import com.yourcompany.mamplus.firestore.PolicyManager
import com.yourcompany.mamplus.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)

        setContent {
            var isLoggedIn by remember { mutableStateOf(false) }
            var userEmail by remember { mutableStateOf("") }
            var accessGranted by remember { mutableStateOf(false) }
            var accessReason by remember { mutableStateOf("") }

            if (!isLoggedIn) {
                LoginScreen(
                    onLoginSuccess = { email ->
                        isLoggedIn = true
                        userEmail = email

                        Log.d("LOGIN", "Logged in as: $userEmail")

                        if (!email.endsWith("@elteranord.com")) {
                            accessGranted = false
                            accessReason = "Unauthorized domain"
                            return@LoginScreen
                        }

                        lifecycleScope.launch {
                            val policy = PolicyManager.getPolicyForUser(email)

                            if (policy.rootCheckEnabled && isDeviceRooted()) {
                                accessReason = "Rooted device detected"
                                accessGranted = false
                                Log.d("RootDetection", "FAIL")
                                return@launch
                            }
                            Log.d("RootDetection", "PASS")

                            if (policy.trustScoreCheckEnabled) {
                                val score = calculateDeviceTrustScore()
                                Log.d("DeviceTrustScore", "Score = $score")
                                if (score < 60) {
                                    accessReason = "Device trust score too low"
                                    accessGranted = false
                                    return@launch
                                }
                                Log.d("DeviceTrustScore", "PASS")
                            }

                            if (policy.networkCheckEnabled) {
                                val deviceIp = getIPAddress()
                                Log.d("NetworkCheck", "Device IP: $deviceIp")
                                Log.d("NetworkCheck", "Trusted range: ${policy.trustedIpRange}")

                                if (deviceIp == null || !isIpInRange(deviceIp, policy.trustedIpRange)) {
                                    accessReason = "Untrusted network IP"
                                    accessGranted = false
                                    Log.d("NetworkCheck", "FAIL")
                                    return@launch
                                }
                                Log.d("NetworkCheck", "PASS")
                            }

                            if (policy.locationRestrictionEnabled) {
                                val locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
                                val providers = listOf(
                                    LocationManager.NETWORK_PROVIDER,
                                    LocationManager.GPS_PROVIDER,
                                    LocationManager.PASSIVE_PROVIDER
                                )

                                var bestLocation: Location? = null
                                for (provider in providers) {
                                    val loc = locationManager.getLastKnownLocation(provider)
                                    if (loc != null && (bestLocation == null || loc.accuracy < bestLocation.accuracy)) {
                                        bestLocation = loc
                                    }
                                }

                                val allowedLat = 56.936607
                                val allowedLon = 24.156800
                                val allowed = bestLocation?.let {
                                    val latDiff = Math.abs(it.latitude - allowedLat)
                                    val lonDiff = Math.abs(it.longitude - allowedLon)
                                    Log.d("LocationCheck", "Device location: lat=${it.latitude}, lon=${it.longitude}")
                                    latDiff <= 0.001 && lonDiff <= 0.001
                                } ?: false

                                if (!allowed) {
                                    accessReason = "Untrusted physical location"
                                    accessGranted = false
                                    Log.d("LocationCheck", "FAIL")
                                    return@launch
                                }

                                Log.d("LocationCheck", "PASS")
                            }

                            if (policy.userBehaviorCheckEnabled) {
                                val currentTime = System.currentTimeMillis()
                                val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                                val lastTime = policy.lastLoginTimestamp
                                val lastModel = policy.lastKnownDeviceModel
                                val lastHour = policy.lastLoginHour

                                val timeDiff = currentTime - lastTime
                                val currentModel = Build.MODEL

                                var riskScore = 0

                                if (lastTime > 0 && timeDiff < 2 * 60 * 1000) {
                                    riskScore += 40 // frequent login
                                }

                                if (lastModel.isNotEmpty() && lastModel != currentModel) {
                                    riskScore += 40 // new device
                                }

                                if (currentHour in 0..5) {
                                    riskScore += 20 // night login
                                }

                                Log.d("UBA", "Risk score: $riskScore")

                                if (riskScore >= 60) {
                                    accessGranted = false
                                    accessReason = "Abnormal behavior detected (risk score: $riskScore)"
                                    return@launch
                                }

                                Log.d("UBA", "PASS")
                                PolicyManager.updateLoginBehavior(email, currentTime, currentModel, currentHour)
                            }

                            if (policy.whitelistCheckEnabled) {
                                val disallowedPackages = listOf("com.example.malware", "com.example.roottool")
                                val pm = packageManager
                                val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                                val found = installedApps.any { app: ApplicationInfo ->
                                    disallowedPackages.contains(app.packageName)
                                }
                                if (found) {
                                    accessReason = "Disallowed application found"
                                    accessGranted = false
                                    Log.d("WhitelistCheck", "FAIL")
                                    return@launch
                                }
                                Log.d("WhitelistCheck", "PASS")
                            }


                            if (policy.blockUnknownSources) {
                                val pm = packageManager
                                val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                                val nonPlayStoreApps = installedApps.filter { app: ApplicationInfo ->
                                    val installer = pm.getInstallerPackageName(app.packageName)
                                    installer == null || installer != "com.android.vending"
                                }
                                if (nonPlayStoreApps.isNotEmpty()) {
                                    accessReason = "Unverified app source detected"
                                    accessGranted = false
                                    Log.d("SourceIntegrity", "FAIL")
                                    return@launch
                                }
                                Log.d("SourceIntegrity", "PASS")
                            }

                            accessGranted = true
                        }
                    }
                )
            } else {
                if (accessGranted) {
                    SecurePortalScreen(userEmail)
                } else {
                    AccessBlockedScreen(reason = accessReason)
                }
            }
        }
    }

    private fun isDeviceRooted(): Boolean {
        val paths = listOf(
            "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su",
            "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su",
            "/data/local/tmp/su"
        )
        return paths.any { File(it).exists() } || (Build.TAGS?.contains("test-keys") == true)
    }

    private fun calculateDeviceTrustScore(): Int {
        var score = 100
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) score -= 40

        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
        val isEncrypted = dpm.storageEncryptionStatus == android.app.admin.DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE
        if (!isEncrypted) score -= 40

        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!keyguardManager.isKeyguardSecure) score -= 20

        return score
    }

    private fun getIPAddress(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            for (intf in interfaces) {
                val addrs = intf.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress
                    }
                }
            }
            null
        } catch (e: Exception) {
            Log.e("NetworkCheck", "getIPAddress() failed: ${e.message}")
            null
        }
    }

    private fun isIpInRange(ip: String, cidr: String): Boolean {
        return try {
            val (network, prefix) = cidr.split("/")
            val ipBytes = InetAddress.getByName(ip).address
            val networkBytes = InetAddress.getByName(network).address
            val mask = (0xFFFFFFFF.toInt() shl (32 - prefix.toInt()))

            val ipInt = ipBytes.fold(0) { acc, byte -> (acc shl 8) or (byte.toInt() and 0xFF) }
            val netInt = networkBytes.fold(0) { acc, byte -> (acc shl 8) or (byte.toInt() and 0xFF) }

            (ipInt and mask) == (netInt and mask)
        } catch (e: Exception) {
            Log.e("NetworkCheck", "CIDR match error: ${e.message}")
            false
        }
    }
}
